

/*Shayna Mitchell
CS 210 Project Three
Corner Grocer Item Tracking Program

The Corner Grocer needs a program that analyzes the text records they generate throughout the day.
These records list items purchased in chronological order from the time the store opens to the time it closes.
They are interested in rearranging their produce section and need to know how often items are purchased so they
can create the most effective layout for their customers.

  Program Functionality:
Prompt a user to input the item, or word, they wish to look for.
Return a numeric value for the frequency of the specific word.
Print the list with numbers that represent the frequency of all items purchased.
The screen output should include every item(represented by a word) paired with the number of times that item appears in the input file,
items are in input file CS210_Project_Three_Input_File.txt
should look like this:
Potatoes 4
Pumpkins 5
Onions 3
Print the same frequency information for all the items in the form of a histogram.
Then print the name, followed by asterisks or another special character to represent the numeric amount.
The number of asterisks should equal the frequency read from the CS210_Project_Three_Input_File.txt file.
Something like this:
  Potatoes ****
  Pumpkins*****
  Onions***
Menu option to Exit the program.
*/

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <map>
#include <iomanip>

using namespace std;

int main() {

    ifstream inFS;

    cout << "Welcome to the Corner Grocer program. Please begin." << endl;

    cout << "Opening file CS210_Project_Three_Input_File.txt." << endl;
    inFS.open("CS210_Project_Three_Input_File.txt");
    if (!inFS.is_open()) {
        cout << "This file could not be opened. You may have it open elsewhere." << endl;
        return 1;
    }
    cout << "Reading file." << endl;

    // Count the items 
    map<string, int> wordFreq;
    string line;
    while (getline(inFS, line)) {
        istringstream iss(line);
        string word;
        while (iss >> word) {
            ++wordFreq[word];
        }
    }

    // Prompt user to look for an item or exit
    string word;
    while (true) {
        cout << "*******************************************************" << endl;
        cout << "*** What item would you like me to search for?  *******" << endl;
        cout << "*** You have some options here.                 *******" << endl;
        cout << "*** You can 1. Type the name of your item,      *******" << endl;
        cout << "*** 2. Type 'histogram' to display all items,   *******" << endl;
        cout << "*** or 3. Type 'exit' to quit.                  *******" << endl;
        cout << "*******************************************************" << endl;
        getline(cin, word);

        if (word == "exit") {
            cout << "Exiting program..." << endl;
            break;
        }
        else if (word == "histogram") {
            cout << "Histogram:" << endl;
            int maxFreq = 0;
            for (auto it = wordFreq.begin(); it != wordFreq.end(); ++it) {
                if (it->second > maxFreq) {
                    maxFreq = it->second;
                }
            }
            int nameWidth = 20;
            int freqWidth = 5;
            for (auto it = wordFreq.begin(); it != wordFreq.end(); ++it) {
                cout << left << setw(nameWidth) << it->first;
                cout << right << setw(freqWidth) << it->second << " ";
                for (int i = 0; i < it->second; ++i) {
                    cout << "*";
                }
                cout << endl;
            }
        }
        else {
            // See about the frequency of this item
            int freq = 0;
            if (wordFreq.count(word)) {
                freq = wordFreq[word];
            }
            cout << "Frequency of \"" << word << "\" in Corner Grocer: " << freq << endl;
        }
    }

    return 0;
}



